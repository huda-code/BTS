Extract and copy the files to the Desktop

copy the snort.conf file to the following location using the following commands:

cp /root/Desktop/snort.conf /etc/snort/

cp /root/Desktop/*.rules /etc/snort/rules/

to analyze the test nessus file run the following command from a terminal window:

snort -c /etc/snort/snort.conf -r /root/Desktop/nessus_scan.pcap

if your snort is working correctly you should get:

1315 SNORT Alerts.

The alerts file is located in /var/log/snort/

